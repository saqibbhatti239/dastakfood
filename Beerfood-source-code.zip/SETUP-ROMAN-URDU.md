# Beerfood setup (Roman Urdu)

## App chalana

1. Node.js install karein.
2. Is folder mein terminal khol kar `npm start` chalayein.
3. Browser mein `http://localhost:3000` kholein. Customer app `/`, admin `/admin`, aur rider `/rider` par hai.

App orders aur catalog ko isi folder ke `data.json` mein save karti hai. Is demo ko public internet par deploy karne se pehle authentication, database, backups aur secure hosting configure karna zaroori hai.

## Phone OTP sign-in

Beerfood sign-in SMS OTP use karta hai. OTP messages bhejne ke liye Twilio Verify account aur Verification Service chahiye; har SMS ki provider billing ho sakti hai.

### Free local testing

Local `.env` mein `NODE_ENV=development` aur `OTP_TEST_MODE=true` set hai. Sign-in modal khud test number `+1 202-555-0147` aur code `583104` dikhayega. Is mode mein koi SMS nahi bheja jata aur koi SMS charge nahi lagta. Yeh sirf is local demo ke liye hai; production deploy par `NODE_ENV=production` aur `OTP_TEST_MODE=false` rakhein.

1. Twilio Console mein Verify Service banayein.
2. Account SID, Auth Token aur Verify Service SID apne local `.env` mein `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN` aur `TWILIO_VERIFY_SERVICE_SID` ke andar set karein.
3. Twilio Verify settings mein Pakistan (+92) SMS Geo Permissions check karein. Trial account par destination number verify karna zaroori ho sakta hai.
4. Beerfood server restart karein. Customer app mein phone number likh kar “Send code” dabayein, phir SMS code enter karke verify karein.

Twilio credentials ko chat, public code repository ya screenshot mein share na karein. Twilio ke mutabiq Verify code bhejne aur code check karne ke liye alag API requests use hoti hain: https://www.twilio.com/docs/verify/api

## Google Maps location

Browser customer ke “Use my current location” button par location permission maangta hai. Location permission user khud allow kare; app bina ijazat location nahin leti. Localhost geolocation ke liye supported secure context hai. Deployed site par HTTPS use karein.

Interactive Google map dikhane ke liye:

1. Google Cloud Console mein project banayein ya apna project select karein.
2. Project ke liye billing account link karein. Google ke mutabiq Maps Embed API requests par charge nahin hota, magar API key aur billing account setup required hain.
3. **Maps Embed API** enable karein aur API key banayein.
4. Key ko API restriction mein sirf **Maps Embed API** tak limit karein. Website restriction mein local development ke liye `http://localhost:3000/*` aur `http://127.0.0.1:3000/*` add karein. Production mein apna HTTPS domain add karein.
5. `.env.example` ki copy bana kar uska naam `.env` rakhein, phir `GOOGLE_MAPS_API_KEY=` ke baad key paste karein.
6. Server band karke dobara `npm start` se chalayein. Location pin select karne ke baad map modal mein nazar aayega.

API key ko GitHub, public chat ya source code mein share na karein. Yeh key browser map request mein istemal hoti hai, is liye API aur website restrictions zaroor lagayein.

Official Google guide: https://developers.google.com/maps/documentation/embed/quickstart
