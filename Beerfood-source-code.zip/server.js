const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sessions = new Map();

const root = __dirname;
const otpSendLimits = new Map();
const otpIpLimits = new Map();
// Load local configuration without requiring a third-party package.
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}
const publicDir = path.join(root, 'public');
const uploadsDir = path.join(publicDir, 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });
const dataFile = path.join(root, 'data.json');
const port = Number(process.env.PORT || 3000);
const googleMapsApiKey = process.env.GOOGLE_MAPS_API_KEY || '';
const otpConfig = {
  accountSid: process.env.TWILIO_ACCOUNT_SID || '',
  authToken: process.env.TWILIO_AUTH_TOKEN || '',
  serviceSid: process.env.TWILIO_VERIFY_SERVICE_SID || '',
  testMode: process.env.NODE_ENV === 'development' && process.env.OTP_TEST_MODE === 'true',
  testPhone: normalizePhone(process.env.OTP_TEST_PHONE || '+1 202-555-0147'),
  testCode: process.env.OTP_TEST_CODE || '583104'
};
const paymentConfig = {
  easypaisa: process.env.EASYPAISA_RECEIVER || '',
  jazzcash: process.env.JAZZCASH_RECEIVER || '',
  bankName: process.env.BANK_NAME || '',
  bankTitle: process.env.BANK_ACCOUNT_TITLE || '',
  bankAccount: process.env.BANK_ACCOUNT_NUMBER || '',
  bankIban: process.env.BANK_IBAN || ''
};
const initial = {
  categories: ['Burgers', 'Biryani', 'Pizza', 'Pakistani', 'Desserts', 'Drinks', 'Groceries', 'Vegetables', 'Home Items'],
  products: [
    { id: 'p1', name: 'Classic Burger', category: 'Burgers', price: 450, emoji: '🍔', description: 'Grilled patty, fresh salad and house sauce', available: true },
    { id: 'p2', name: 'Chicken Biryani', category: 'Biryani', price: 520, emoji: '🍛', description: 'Aromatic rice with tender chicken', available: true },
    { id: 'p3', name: 'Cheese Pizza', category: 'Pizza', price: 850, emoji: '🍕', description: 'Stone baked with mozzarella and herbs', available: true },
    { id: 'p4', name: 'Chicken Karahi', category: 'Pakistani', price: 1200, emoji: '🥘', description: 'Traditional karahi, serves two', available: true },
    { id: 'p5', name: 'Chocolate Cake', category: 'Desserts', price: 350, emoji: '🍰', description: 'Rich chocolate slice', available: true },
    { id: 'p6', name: 'Fresh Lemonade', category: 'Drinks', price: 180, emoji: '🍋', description: 'Freshly squeezed, served chilled', available: true },
    { id: 'p7', name: 'Fresh Tomatoes (1 kg)', category: 'Groceries', price: 160, emoji: '🍅', description: 'Local fresh produce', available: true },
    { id: 'p8', name: 'Fresh Milk (1 litre)', category: 'Groceries', price: 230, emoji: '🥛', description: 'Fresh dairy from a nearby shop', available: true },
    { id: 'p9', name: 'Farm Eggs (dozen)', category: 'Groceries', price: 360, emoji: '🥚', description: 'A dozen fresh eggs', available: true },
    { id: 'p10', name: 'Potatoes (1 kg)', category: 'Vegetables', price: 110, emoji: '🥔', description: 'Fresh local produce', available: true },
    { id: 'p11', name: 'Spinach Bunch', category: 'Vegetables', price: 90, emoji: '🥬', description: 'Fresh greens from the local market', available: true },
    { id: 'p12', name: 'Dish Soap', category: 'Home Items', price: 240, emoji: '🧼', description: 'Everyday home cleaning essential', available: true },
    { id: 'p13', name: 'Laundry Detergent', category: 'Home Items', price: 520, emoji: '🧺', description: 'Household pack', available: true }
  ],
  orders: [],
  riderStatuses: {},
  supportTickets: []
};
function readData() {
  if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify(initial, null, 2));
  try { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); }
  catch { return structuredClone(initial); }
}
let data = readData();
if (!Array.isArray(data.users)) data.users = [];
if (!Array.isArray(data.supportTickets)) data.supportTickets = [];
if (!data.categoryImages || typeof data.categoryImages !== 'object') data.categoryImages = {};
if (!data.riderStatuses || typeof data.riderStatuses !== 'object') data.riderStatuses = {};
function save() { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }
function saveImage(dataUrl) {
  if (!dataUrl) return '';
  const match = String(dataUrl).match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new Error('Choose a PNG, JPG or WebP image.');
  const bytes = Buffer.from(match[2], 'base64');
  if (!bytes.length || bytes.length > 3 * 1024 * 1024) throw new Error('Image must be smaller than 3 MB.');
  const extension = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' }[match[1]];
  const filename = `${crypto.randomUUID()}.${extension}`;
  fs.writeFileSync(path.join(uploadsDir, filename), bytes, { flag: 'wx' });
  return `/uploads/${filename}`;
}
function publicUser(user) { return { id: user.id, name: user.name, phone: user.phone }; }
function normalizePhone(value) {
  let phone = String(value || '').replace(/\D/g, '');
  if (phone.startsWith('0092')) phone = `0${phone.slice(4)}`;
  else if (phone.startsWith('92') && phone.length === 12) phone = `0${phone.slice(2)}`;
  return phone;
}
function sessionUser(req) {
  const token = (req.headers.cookie || '').split(';').map(value => value.trim()).find(value => value.startsWith('beerfood_session='))?.slice('beerfood_session='.length);
  const session = token && sessions.get(token);
  if (!session || session.expiresAt < Date.now()) { if (token) sessions.delete(token); return null; }
  return data.users.find(user => user.id === session.userId) || null;
}
function setSessionCookie(req, res, token, maxAge) {
  const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `beerfood_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure}`);
}
function e164Phone(value) {
  const phone = normalizePhone(value);
  if (phone.startsWith('0')) return `+92${phone.slice(1)}`;
  if (phone.length === 10 && phone.startsWith('3')) return `+92${phone}`;
  return `+${phone}`;
}
async function twilioVerify(pathname, fields) {
  const endpoint = `https://verify.twilio.com/v2/Services/${encodeURIComponent(otpConfig.serviceSid)}/${pathname}`;
  const auth = Buffer.from(`${otpConfig.accountSid}:${otpConfig.authToken}`).toString('base64');
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(fields),
    signal: AbortSignal.timeout(12000)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error('SMS code could not be sent or verified. Check Twilio setup and SMS country permissions.');
    error.statusCode = response.status;
    error.providerCode = result.code;
    throw error;
  }
  return result;
}
function send(res, status, value, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(type.startsWith('application/json') ? JSON.stringify(value) : value);
}
async function body(req) {
  let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > 5_000_000) throw new Error('Request too large. Keep uploaded images below 3 MB.'); }
  return raw ? JSON.parse(raw) : {};
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) {
      if (req.method === 'GET' && url.pathname === '/api/state') return send(res, 200, { categories: data.categories, categoryImages: data.categoryImages, products: data.products, orders: data.orders, supportTickets: data.supportTickets, riderStatuses: data.riderStatuses });
      if (req.method === 'GET' && url.pathname === '/api/payment-config') return send(res, 200, paymentConfig);
      if (req.method === 'GET' && url.pathname === '/api/location-config') return send(res, 200, { googleMapsApiKey });
      if (req.method === 'GET' && url.pathname === '/api/auth/config') return send(res, 200, otpConfig.testMode ? { testMode: true, testPhone: e164Phone(otpConfig.testPhone), testCode: otpConfig.testCode } : { testMode: false });
      if (req.method === 'GET' && url.pathname === '/api/auth/me') return send(res, 200, { user: (user => user ? publicUser(user) : null)(sessionUser(req)) });
      if (req.method === 'POST' && url.pathname === '/api/auth/otp/start') {
        const input = await body(req);
        const phone = normalizePhone(input.phone), mode = input.mode === 'register' ? 'register' : 'login';
        const name = String(input.name || '').trim().slice(0, 80);
        if (phone.length < 10 || phone.length > 15) return send(res, 400, { error: 'Enter a valid phone number.' });
        if (mode === 'register' && name.length < 2) return send(res, 400, { error: 'Enter your name to create a new account.' });
        if (mode === 'register' && data.users.some(user => user.phone === phone)) return send(res, 409, { error: 'This phone already has an account. Choose Sign in instead.' });
        if (otpConfig.testMode) {
          if (phone !== otpConfig.testPhone) return send(res, 400, { error: `Free local testing only accepts this fictional number: ${otpConfig.testPhone}.` });
          return send(res, 200, { ok: true, testMode: true, testPhone: e164Phone(otpConfig.testPhone), testCode: otpConfig.testCode });
        }
        if (!otpConfig.accountSid || !otpConfig.authToken || !otpConfig.serviceSid) return send(res, 503, { error: 'SMS OTP is not configured yet. Add the Twilio settings in .env first.' });
        const lastSent = otpSendLimits.get(phone) || 0;
        if (Date.now() - lastSent < 60_000) return send(res, 429, { error: 'Please wait 60 seconds before requesting another code.' });
        const ip = req.socket.remoteAddress || 'unknown';
        const recentIpSends = (otpIpLimits.get(ip) || []).filter(time => Date.now() - time < 60 * 60 * 1000);
        if (recentIpSends.length >= 10) return send(res, 429, { error: 'Too many code requests from this connection. Try again in an hour.' });
        recentIpSends.push(Date.now()); otpIpLimits.set(ip, recentIpSends);
        otpSendLimits.set(phone, Date.now());
        const verification = await twilioVerify('Verifications', { To: e164Phone(phone), Channel: 'sms' });
        if (verification.status !== 'pending') return send(res, 502, { error: 'The SMS provider did not start the verification.' });
        return send(res, 200, { ok: true, message: 'Verification code sent by SMS.' });
      }
      if (req.method === 'POST' && url.pathname === '/api/auth/otp/verify') {
        const input = await body(req);
        const phone = normalizePhone(input.phone), code = String(input.code || '').trim();
        if (phone.length < 10 || phone.length > 15 || !/^\d{4,10}$/.test(code)) return send(res, 400, { error: 'Enter the phone number and SMS code.' });
        let result;
        if (otpConfig.testMode) {
          if (phone !== otpConfig.testPhone || code !== otpConfig.testCode) return send(res, 400, { error: 'Test phone or code is incorrect.' });
          result = { status: 'approved' };
        } else {
          if (!otpConfig.accountSid || !otpConfig.authToken || !otpConfig.serviceSid) return send(res, 503, { error: 'SMS OTP is not configured yet. Add the Twilio settings in .env first.' });
          result = await twilioVerify('VerificationCheck', { To: e164Phone(phone), Code: code });
        }
        if (result.status !== 'approved') return send(res, 400, { error: 'That code is incorrect or expired. Request a new code and try again.' });
        let user = data.users.find(item => item.phone === phone);
        if (!user) {
          const name = String(input.name || '').trim().slice(0, 80);
          if (input.mode !== 'register' || name.length < 2) return send(res, 404, { error: 'No account found for this number. Choose Create account and request a new code.' });
          user = { id: crypto.randomUUID(), name, phone, createdAt: new Date().toISOString(), phoneVerifiedAt: new Date().toISOString() };
          data.users.push(user); save();
        } else if (!user.phoneVerifiedAt) { user.phoneVerifiedAt = new Date().toISOString(); save(); }
        const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, { userId: user.id, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 });
        setSessionCookie(req, res, token, 7 * 24 * 60 * 60);
        return send(res, 200, { user: publicUser(user) });
      }
      if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
        const token = (req.headers.cookie || '').split(';').map(value => value.trim()).find(value => value.startsWith('beerfood_session='))?.slice('beerfood_session='.length);
        if (token) sessions.delete(token);
        setSessionCookie(req, res, '', 0);
        return send(res, 200, { ok: true });
      }
      if (req.method === 'POST' && url.pathname === '/api/orders') {
        const input = await body(req);
        if (!input.customerName?.trim() || !input.phone?.trim() || !input.address?.trim() || !Array.isArray(input.items) || !input.items.length) return send(res, 400, { error: 'Name, phone, address and at least one item are required.' });
        const payment = String(input.payment || 'Cash on Delivery');
        const paymentTargets = { Easypaisa: paymentConfig.easypaisa, JazzCash: paymentConfig.jazzcash, 'Bank transfer': paymentConfig.bankIban || paymentConfig.bankAccount };
        if (payment !== 'Cash on Delivery' && !paymentTargets[payment]) return send(res, 400, { error: `${payment} details are not configured yet. Choose Cash on Delivery or set up the merchant account first.` });
        if (payment !== 'Cash on Delivery' && !String(input.transactionReference || '').trim()) return send(res, 400, { error: 'Enter the payment transaction reference to submit your order for verification.' });
        const items = input.items.map(line => { const product = data.products.find(p => p.id === line.productId && p.available); return product ? { productId: product.id, name: product.name, price: product.price, quantity: Math.max(1, Number(line.quantity) || 1), emoji: product.emoji } : null; }).filter(Boolean);
        if (!items.length) return send(res, 400, { error: 'Selected items are no longer available.' });
        const hasCoords = input.location && Number.isFinite(Number(input.location.lat)) && Number.isFinite(Number(input.location.lng));
        const area = String(input.location?.area || '').trim().slice(0, 240);
        const location = hasCoords ? { area, lat: Number(input.location.lat), lng: Number(input.location.lng) } : area ? { area } : null;
        const order = { id: crypto.randomUUID(), orderNumber: `BF-${String(Date.now()).slice(-7)}`, customerName: input.customerName.trim(), phone: input.phone.trim(), address: input.address.trim(), location, items, subtotal: items.reduce((sum, item) => sum + item.price * item.quantity, 0), deliveryFee: 100, total: 0, payment, transactionReference: payment === 'Cash on Delivery' ? '' : String(input.transactionReference).trim(), paymentStatus: payment === 'Cash on Delivery' ? 'Pay on delivery' : 'Pending manual verification', status: 'New', rider: '', createdAt: new Date().toISOString() };
        order.total = order.subtotal + order.deliveryFee; data.orders.unshift(order); save(); return send(res, 201, order);
      }
      if (req.method === 'POST' && url.pathname === '/api/support') {
        const input = await body(req), rider = String(input.rider || '').trim().slice(0, 80), message = String(input.message || '').trim().slice(0, 1200), issue = String(input.issue || '').trim().slice(0, 80);
        if (!rider || !message || !issue) return send(res, 400, { error: 'Rider name, issue type and message are required.' });
        const ticket = { id: crypto.randomUUID(), rider, orderId: String(input.orderId || '').slice(0, 100), orderNumber: String(input.orderNumber || '').slice(0, 40), issue, message, status: 'Open', createdAt: new Date().toISOString() };
        data.supportTickets.unshift(ticket); save(); return send(res, 201, ticket);
      }
      const supportMatch = url.pathname.match(/^\/api\/support\/([^/]+)$/);
      if (req.method === 'PATCH' && supportMatch) {
        const ticket = data.supportTickets.find(item => item.id === supportMatch[1]); if (!ticket) return send(res, 404, { error: 'Support request not found.' });
        const input = await body(req); if (!['Open', 'In Progress', 'Resolved'].includes(input.status)) return send(res, 400, { error: 'Invalid support status.' });
        ticket.status = input.status; ticket.updatedAt = new Date().toISOString(); save(); return send(res, 200, ticket);
      }
      if (req.method === 'POST' && url.pathname === '/api/categories') {
        const input = await body(req); const value = String(input.name || '').trim();
        if (!value) return send(res, 400, { error: 'Category name is required.' });
        if (!data.categories.some(c => c.toLowerCase() === value.toLowerCase())) data.categories.push(value);
        if (input.imageData) data.categoryImages[value] = saveImage(input.imageData);
        save(); return send(res, 201, { categories: data.categories, categoryImages: data.categoryImages });
      }
      if (req.method === 'POST' && url.pathname === '/api/products') {
        const input = await body(req); const name = String(input.name || '').trim(); const price = Number(input.price);
        if (!name || !data.categories.includes(input.category) || !Number.isFinite(price) || price < 1) return send(res, 400, { error: 'Enter item name, valid category and price.' });
        const product = { id: crypto.randomUUID(), name, category: input.category, price, emoji: String(input.emoji || '🛍️').slice(0, 8), description: String(input.description || '').slice(0, 180), image: input.imageData ? saveImage(input.imageData) : '', available: true };
        data.products.unshift(product); save(); return send(res, 201, product);
      }
      const productMatch = url.pathname.match(/^\/api\/products\/([^/]+)$/);
      if (req.method === 'PATCH' && productMatch) { const p = data.products.find(item => item.id === productMatch[1]); if (!p) return send(res, 404, { error: 'Item not found.' }); p.available = !p.available; save(); return send(res, 200, p); }
      if (req.method === 'DELETE' && productMatch) { data.products = data.products.filter(item => item.id !== productMatch[1]); save(); return send(res, 200, { ok: true }); }
      const riderAvailabilityMatch = url.pathname.match(/^\/api\/riders\/([^/]+)\/availability$/);
      if (req.method === 'PATCH' && riderAvailabilityMatch) {
        const rider = decodeURIComponent(riderAvailabilityMatch[1]).slice(0, 80), input = await body(req);
        if (!rider || typeof input.online !== 'boolean') return send(res, 400, { error: 'Choose a rider and online status.' });
        if (!data.orders.some(order => order.rider === rider)) return send(res, 404, { error: 'Rider not found.' });
        const status = { online: input.online, updatedAt: new Date().toISOString() };
        data.riderStatuses[rider] = status; save(); return send(res, 200, { rider, ...status });
      }
      const orderMatch = url.pathname.match(/^\/api\/orders\/([^/]+)(?:\/(assign|status|payment))?$/);
      if (orderMatch && req.method === 'PATCH') {
        const order = data.orders.find(item => item.id === orderMatch[1]); if (!order) return send(res, 404, { error: 'Order not found.' });
        const input = await body(req);
        if (orderMatch[2] === 'assign') { order.rider = String(input.rider || '').trim(); if (order.rider && order.status === 'New') order.status = 'Confirmed'; }
        else if (orderMatch[2] === 'status') { const allowed = ['Confirmed', 'Preparing', 'Ready for Pickup', 'Picked Up', 'On the Way', 'Delivered', 'Cancelled', 'Unable to Deliver']; if (!allowed.includes(input.status)) return send(res, 400, { error: 'Invalid order status.' }); order.status = input.status; }
        else if (orderMatch[2] === 'payment') { const allowed = ['Pending manual verification', 'Verified', 'Rejected', 'Pay on delivery']; if (!allowed.includes(input.paymentStatus)) return send(res, 400, { error: 'Invalid payment status.' }); order.paymentStatus = input.paymentStatus; order.paymentCheckedAt = new Date().toISOString(); }
        else { return send(res, 400, { error: 'Choose assign or status.' }); }
        order.updatedAt = new Date().toISOString(); save(); return send(res, 200, order);
      }
      return send(res, 404, { error: 'API route not found.' });
    }
    const file = url.pathname === '/admin' ? 'admin.html' : url.pathname === '/rider' ? 'rider.html' : url.pathname === '/' || url.pathname === '/customer' ? 'index.html' : url.pathname.slice(1);
    const full = path.resolve(publicDir, file);
    if (!full.startsWith(publicDir + path.sep) || !fs.existsSync(full) || !fs.statSync(full).isFile()) return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
    const ext = path.extname(full); const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };
    send(res, 200, fs.readFileSync(full), types[ext] || 'application/octet-stream');
  } catch (error) {
    const status = error.providerCode ? 502 : error.name === 'TimeoutError' ? 504 : 400;
    const message = error.providerCode ? error.message : error.name === 'TimeoutError' ? 'SMS provider timed out. Try again.' : error.message || 'Request could not be processed.';
    send(res, status, { error: message });
  }
});
server.listen(port, '127.0.0.1', () => console.log(`Beerfood is running at http://localhost:${port}`));


